import java.lang.Integer;
import java.lang.String;
import java.io.*;
import java.util.StringTokenizer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Properties;

public class ioTest
{
          static short datum;
          static short Addr;
	    static pPort lpt;

    static String do_read()
    {
          // Read from the port
          datum = (short) lpt.input(Addr);

          // Notify the console
          System.out.println("Read Port: " + Integer.toHexString(Addr) +
                              " = " +  Integer.toHexString(datum)+" And Binary String is " +  Integer.toBinaryString(datum));
          return Integer.toBinaryString(datum);
    }

     static void do_write()
     {
          // Notify the console
          System.out.println("Write to Port: " + Integer.toHexString(Addr) +
                              " with data = " +  Integer.toHexString(datum));
          //Write to the port
          lpt.output(Addr,datum);
     }


     static void do_read_range()
     {
          // Try to read 0x378..0x37F, LPT1:
          for (Addr=0x378; (Addr<0x380); Addr++) {

               //Read from the port
               datum = (short) lpt.input(Addr);

               // Notify the console
               System.out.println("Port: " + Integer.toHexString(Addr) +
                                   " = " +  Integer.toHexString(datum));
          }
     }
     
      public static String replaceCharAt(String s, int pos, char c) {
    return s.substring(0, pos) + c + s.substring(pos + 1);
  }
     
     
     

     public static void main( String args[] )
     {

	    lpt = new pPort();
 
          // Try to read 0x378..0x37F, LPT1:

           do_read_range();


     //  Write the data register

     Addr=0x378;
     datum=0x88;
     do_write();


     // And read back to verify
     do_read();

     //  One more time, different value
     datum=0x92;
     do_write();

     // And read back to verify
     do_read();

     // etc.... one more time now control port
     Addr=0x378;
     datum=0xcc;
     do_write();
     
     Addr++;
     do_read();
     

     Addr++;
     do_read();

     Addr--;
     do_read();
     Addr--;
     do_read();
     
     do_read_range();

     System.out.print("Enter Your Message: ");
     
     //  open up standard input
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        
        String msg = null;

      //  read the username from the command-line; need to use try/catch with the
      //  readLine() method
      try {
         msg = br.readLine();
      } catch (IOException ioe) {
         System.out.println("IO error trying to read your name!");
         System.exit(1);
      }

      System.out.println("Thanks for the message: " + msg);
     
      
      
      String[][] AreaName = new String[8][3];
      try {
         String driver = "com.mysql.jdbc.Driver";

         Class.forName(driver).newInstance();
         Connection conn = null;
         conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smslib?autoReconnect=true","smslib","smslib");
         Statement s = conn.createStatement();
         ResultSet rs = s.executeQuery("SELECT name,device_name,pin_number  FROM device_name");
         
         int i = 0;
         while(rs.next()) {
            System.out.println("name   : "+ rs.getString(1));
            AreaName[i][0] = rs.getString(1);
            System.out.println("Device Name : "+ rs.getString(2));
            AreaName[i][1] = rs.getString(2);
            System.out.println("Pin Number: "+ rs.getString(3));
            AreaName[i][2] = rs.getString(3);
            System.out.println();
            i++;
         }

         rs.close();
         s.close();
         conn.close();
      } catch(Exception e) {
         System.out.println("Exception: "+ e);
         e.printStackTrace();
      }
      
      
      
      
      
      
      
      
      StringTokenizer Entertokens = new StringTokenizer(msg, "\r",true);
      
      
      
      if(Entertokens.countTokens() == 1)
      {
         System.out.println("Enter Token is "+Entertokens.countTokens());
         StringTokenizer commatokens = new StringTokenizer(msg, ",", true);
         if(commatokens.countTokens() == 1)
         {
             System.out.println("Comma Token is "+commatokens.countTokens());
             StringTokenizer spacetokens = new StringTokenizer(msg, " ");
             if(spacetokens.countTokens() == 1)
             {
                 System.out.println("Space Token is "+spacetokens.countTokens());
                 //String commandname = "Status";
                 if("STATUS".equals(msg.trim().toUpperCase()))
                 {
                      // pst.setString(11, "STATUS");
                      //SendStatusMessage();
                      Addr=0x378;
                      do_read();
                      String stat = do_read();
                      int statlength = stat.length();
                      System.out.println("Binary Number is "+stat+" And Stat Length is "+statlength);
                      if(statlength<8)
                      {
                           for (int i=0;i<(8-statlength);i++)
                           {
                               stat = "0".concat(stat);
                               System.out.println("Concatenated string "+stat);
                           }
                      }
                      char[] chars = stat.toCharArray();
                      String SmsOut = "";                               
                      for(int i = 7; i >=0; i--)
                      {
                          
                          if("1".equals(String.valueOf(chars[i])))
                          {
                               System.out.println(AreaName[7-i][0]+" is "+"ON");
                               if(i==7)
                               {
                                    SmsOut = SmsOut.concat(AreaName[7-i][0]+" is "+"ON");
                               }
                               else
                               {
                                    SmsOut = SmsOut.concat("\n"+AreaName[7-i][0]+" is "+"ON");
                               }
                               System.out.println(SmsOut);
                          }
                          else
                          {
                               System.out.println(AreaName[7-i][0]+" is "+"OFF");
                               if(i==7)
                               {
                                    SmsOut = SmsOut.concat(AreaName[7-i][0]+" is "+"OFF");
                               }
                               else
                               {
                                    SmsOut = SmsOut.concat("\n"+AreaName[7-i][0]+" is "+"OFF");
                               }
                               
                               System.out.println(SmsOut);
                          }      
                                                                        
                      }
                                                                
                      for(int i = 12; i <52; i++)
                      {
                           //pst.setString(i,null)
                           System.out.println("Field Number is "+i);
                      }
                      System.out.println("Command is "+spacetokens.nextToken());
                 }
                 else
                 {
                      System.out.println("Command is not Status, Command is "+spacetokens.nextToken());
                      //SendErrorMessage();
                 }
             }
             else
             {
                 if(spacetokens.countTokens() >4)
                 {
                     System.out.println("Command Is More Than "+spacetokens.countTokens());
                     //  SendErrorMessage();
                 }
                 else
                 {
                     // pst.setString(11, null);
                     int fieldnumber = 12;
                     String PinNumber = "";
                     String PinCommand = "";
                     int aPinNumberInt = 0;
                     while(spacetokens.hasMoreTokens())
                     {
                          if (fieldnumber==12)
                          {
                             //   pst.setString(fieldnumber, (subtokens.nextToken().length() == 0 ? "" : subtokens.nextToken()));
                             //System.out.println("fieldNumber is "+fieldnumber+" and Spacetoken Is  "+spacetokens.nextToken());
                             
                             String TokenAreaName = spacetokens.nextToken();
                             for(int i=0;i<8;i++)
                             {
                                 if (AreaName[i][0].toUpperCase().equals(TokenAreaName.trim().toUpperCase()))
                                 {
                                     PinNumber = AreaName[i][2];
                                     System.out.println(TokenAreaName+" Area Name is found in database And Pin Number is "+PinNumber);
                                     aPinNumberInt = Integer.parseInt(PinNumber);
                                     
                                     switch (aPinNumberInt)
						{
							case 1:
								aPinNumberInt =7;
								break;
							case 2:
								aPinNumberInt =6;
								break;
							case 3:
								aPinNumberInt =5;
								break;
							case 4:
								aPinNumberInt =4;
								break;
                                                        case 5:
								aPinNumberInt =3;
								break;
                                                        case 6:
								aPinNumberInt =2;
								break;
                                                        case 7:
								aPinNumberInt =1;
								break;
                                                        case 8:
								aPinNumberInt =0;
								break;
						}
                                     
                                 }
                             }
                             if ("".equals(PinNumber.trim()))
                             {
                                   System.out.println(TokenAreaName+" Area Name Not found in database");
                                   //  SendErrorMessage();
                             }
                                                                                
                          }
                          else
                          {
                                String TokenCommandName =  spacetokens.nextToken();
                                System.out.println("fieldNumber is "+fieldnumber+" and Spacetoken Is  "+TokenCommandName);  
                                
                                if ("ON".equals(TokenCommandName.trim().toUpperCase()))
                                {
                                     PinCommand = "1";
                                     System.out.println("Command is "+TokenCommandName+" And PinCommand is "+PinCommand);
                                     //  SendErrorMessage();
                                }
                                else if("OFF".equals(TokenCommandName.trim().toUpperCase()))
                                {
                                     PinCommand = "0";
                                     System.out.println("Command is "+TokenCommandName+" And PinCommand is "+PinCommand);  
                                }
                                else if("TG".equals(TokenCommandName.trim().toUpperCase()))
                                {
                                     PinCommand = "1";
                                     System.out.println("Command is "+TokenCommandName+" And PinCommand is "+PinCommand);
                                }
                                                          
                          }
                          fieldnumber++;
                                                                                
                     }
                     
                     Addr=0x378;
                      do_read();
                      String stat = do_read();
                      int statlength = stat.length();
                      System.out.println("Binary Number is "+stat+" And Stat Length is "+statlength);
                      if(statlength<8)
                      {
                           for (int i=0;i<(8-statlength);i++)
                           {
                               stat = "0".concat(stat);
                               System.out.println("Concatenated string "+stat);
                           }
                      }
                      char[] chars = stat.toCharArray();
                      System.out.println("Binary String Before replacement: "+stat);
                      //int aPinNumberInt = Integer.parseInt(PinNumber);
                      char firstLetter = PinCommand.charAt(0);
                      stat = replaceCharAt(stat, aPinNumberInt, firstLetter); 
                      System.out.println("Binary String After replacement: "+stat);
                      Addr=0x378;
                      String writedatum = Integer.toHexString(Integer.parseInt(stat,2));
                      System.out.println("Check To See hexstring : "+writedatum);
                      //datum = writedatum;
                      datum = Short.parseShort(writedatum, 16) ;
                      //Short sObj2 = Short.valueOf(str);
                      do_write();
                      stat = do_read();
                      System.out.println("Check To See if we write properly: "+stat);
                     if(fieldnumber==14)
                     {
                        for(int i = 14; i <52; i++)
                        {
                            //pst.setString(i,null)
                            System.out.println("Field Number is "+i);
                        }
                     }
                     else
                     {
                        if(fieldnumber==15)
                        {
                           System.out.println("Unfinished command. Need another token");
                           for(int i = 15; i <52; i++)
                           {
                               //pst.setString(i,null)
                               System.out.println("Field Number is "+i);
                           }
                        }
                        else
                        {                                                                     
                           for(int i = 16; i <52; i++)
                           {
                               //pst.setString(i,null)
                               System.out.println("Field Number is "+i);
                           }
                        }
                        System.out.println("We are in tg mode. Field Number is ");
                     }
                 }
             }
         }
         else
         {
             if(commatokens.countTokens() > 7)
             {
                // SendErrorMessage();
             }
             else
             {
                System.out.println("Comma Token is "+commatokens.countTokens());
                int fieldnumber = 12;
                int firstset = 1;
                int separatorset = 1;
                boolean ISItFirstComma = true;
                while(commatokens.hasMoreTokens())
                {
                     // System.out.println(commatokens.nextToken());
                                                    
                                                                          //  pst.setString(fieldnumber, (tokens.nextToken().length() == 0 ? "" : "Enter"));
                                                                                
                                                                            String linecut = commatokens.nextToken().trim();
                                                                            StringTokenizer spacetokens = new StringTokenizer(linecut, " ");
                                                                            int highestToken = spacetokens.countTokens();
                                                                            System.out.println("Highest Space Token in a Comma Token is: "+highestToken);
                                                                            String FirstSpaceToken = spacetokens.nextToken();
                                                                            
                                                                            
                                                                            if(",".equals(FirstSpaceToken.trim()) & ISItFirstComma & fieldnumber==12)
                                                                            {
                                                                                ISItFirstComma = true;
                                                                                //SendErrorMessage("You Put Comma First"); 
                                                                                System.out.println("You Put a Comma before anything....Separator_"+separatorset+" : "+FirstSpaceToken);
                                                                                separatorset++;
                                                                                fieldnumber++;
                                                                                System.out.println("FieldNumber is :"+fieldnumber);
                                                                            }
                                                                            
                                                                            else if(",".equals(FirstSpaceToken.trim()) & ISItFirstComma)
                                                                            {
                                                                                ISItFirstComma = true;
                                                                                //SendErrorMessage("You Put Comma First"); 
                                                                                System.out.println("You Put a Comma after a comma....Separator_"+separatorset+" : "+FirstSpaceToken);
                                                                                separatorset++;
                                                                                fieldnumber++;
                                                                                System.out.println("FieldNumber is :"+fieldnumber);
                                                                            }
                                                                            else if(",".equals(FirstSpaceToken.trim()))
                                                                                    {
                                                                                     ISItFirstComma = true;   
                                                                                     System.out.println("Separator_"+separatorset+" : "+FirstSpaceToken);
                                                                                     separatorset++;
                                                                                     fieldnumber++;
                                                                                     System.out.println("FieldNumber is :"+fieldnumber);   
                                                                                    }
                                                                            else
                                                                            {
                                                                                if(highestToken==4)
                                                                                {
                                                                                    String DB_CONN_STRING = "jdbc:mysql://localhost:3306/smslib";
                                                                                    String DRIVER_CLASS_NAME = "com.mysql.jdbc.Driver";
                                                                                    String USER_NAME = "smslib";
                                                                                    String PASSWORD = "smslib";
                                                                                    
                                                                                    Connection result = null;
                                                                                    try {
                                                                                            Class.forName(DRIVER_CLASS_NAME).newInstance();
                                                                                        }
                                                                                    catch (Exception ex){
                                                                                            log("Check classpath. Cannot load db driver: " + DRIVER_CLASS_NAME);
                                                                                        }
                                                                                    
                                                                                    try {
                                                                                        result = DriverManager.getConnection(DB_CONN_STRING, USER_NAME, PASSWORD);
                                                                                        }
                                                                                    catch (SQLException e){
                                                                                    log( "Driver loaded, but cannot connect to db: " + DB_CONN_STRING);
                                                                                        }
                                                                                    // return result;
                                                                                    
                                                                                    String query = "";
                                                                                    try {
                                                                                    Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/smslib", "smslib", "smslib");
                                                                                    
                                                                                    //Connection con = DriverManager.getConnection("jdbc:com.mysql.jdbc.Driver:smslib", "smslib","smslib");
                                                                                    
                                                                                    
                                                                                    Statement stmt = con.createStatement();
                                                                                    ResultSet rs = stmt.executeQuery("SELECT device_name FROM DEVICE_NAME");
                                                                                    while (rs.next()) {
                                                                                        //int x = rs.getInt("a");
                                                                                        String s = rs.getString("name");
                                                                                        System.out.println("Device_name_"+firstset+" : "+s);
                                                                                        //float f = rs.getFloat("c");
                                                                                        }
                                                                                    
                                                                                    }
                                                                                    catch (SQLException ex) {
                                                                                        ex.printStackTrace();
                                                                                        System.out.println(query);
                                                                                    }
                                                                                    
                                                                                    System.out.println("Device_name_"+firstset+" : "+FirstSpaceToken);
                                                                                    System.out.println("Device_name_"+firstset+" : "+"//pst.setString("+fieldnumber+",null)");
                                                                                    fieldnumber++;
                                                                                    System.out.println("FieldNumber is :"+fieldnumber);
                                                                                    System.out.println("Command_name_"+firstset+" : "+spacetokens.nextToken());
                                                                                    fieldnumber++;
                                                                                    System.out.println("FieldNumber is :"+fieldnumber);
                                                                                    System.out.println("from_toggle_"+firstset+" : "+spacetokens.nextToken());
                                                                                    fieldnumber++;
                                                                                    System.out.println("FieldNumber is :"+fieldnumber);
                                                                                    System.out.println("to_toggle_"+firstset+" : "+spacetokens.nextToken());
                                                                                    fieldnumber++;
                                                                                    System.out.println("FieldNumber is :"+fieldnumber);
                                                                                    switch (highestToken)
                                                                                    {
                                                                                        case 1:
                                                                                        
                                                                                            System.out.println("Only One Word.."+spacetokens.nextToken()+" use Two words");
                                                                                            //SendErrorMessage("Only one word"); 
                                                                                            //fieldnumber= fieldnumber+3;
                                                                                            break;
                                                                                        case 2:
                                                                                        
                                                                                            fieldnumber= fieldnumber+2;
                                                                                            break;
                                                                                        case 3:
                                                                                            fieldnumber= fieldnumber+1;
                                                                                            break;
                                                                                    
                                                                                    }
                                                                                    
                                                                                }
                                                                                else
                                                                                {
                                                                                    ISItFirstComma = false;
                                                                                    System.out.println("Device_name_"+firstset+" : "+FirstSpaceToken);
                                                                                    fieldnumber++;
                                                                                    System.out.println("FieldNumber is :"+fieldnumber);
                                                                                    System.out.println("Command_name_"+firstset+" : "+spacetokens.nextToken());
                                                                                    fieldnumber++;
                                                                                    System.out.println("FieldNumber is :"+fieldnumber);
                                                                                    //pst.setString(i,null)
                                                                                    System.out.println("from_toggle_"+firstset+" : "+"//pst.setString("+fieldnumber+",null)");
                                                                                    fieldnumber++;
                                                                                    System.out.println("FieldNumber is :"+fieldnumber);
                                                                                    System.out.println("to_toggle_"+firstset+" : "+"//pst.setString("+fieldnumber+",null)");
                                                                                    fieldnumber++;
                                                                                    System.out.println("FieldNumber is :"+fieldnumber);
                                                                                    firstset++;
                                                                                }    
                                                                            }
                                                                  }
      
      
      
     
    }
     


}
